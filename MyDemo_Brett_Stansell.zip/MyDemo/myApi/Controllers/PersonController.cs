﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using myData;
using Newtonsoft.Json;
using Microsoft.Extensions.Logging;

namespace myApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonController : ControllerBase
    {
        private PersonRepository _personRepository;
        private Logger<string> _logger;

        public PersonController(PersonRepository personRepository, Logger<string> logger)
        {
            _personRepository = personRepository;
            _logger = logger;
        }

        // GET: api/Person
        [HttpGet]
        public string Get()
        {
            try
            {
                _logger.Log(LogLevel.Information, "Get Invoked", null);
                MyStupidPersonMapper mapper = new MyStupidPersonMapper();
                return (JsonConvert.SerializeObject(mapper.GetPersonList(personDtoList: _personRepository.GetPersons())));
            }
            catch (Exception ex)
            {
                _logger.Log(LogLevel.Error, ex.Message);
                return (null);
            }
        }

        // GET: api/Person/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            try
            {
                _logger.Log(LogLevel.Information, "Get By Id Invoked", null);
                MyStupidPersonMapper mapper = new MyStupidPersonMapper();
                return (JsonConvert.SerializeObject(mapper.GetPerson(_personRepository.GetPerson(id))));
            }
            catch(Exception ex)
            {
                _logger.Log(LogLevel.Error, ex.Message);
                return (null);
            }
        }

        // POST: api/Person
        [HttpPost]
        public void Post([FromBody] string value)
        {
            try
            {
                _logger.Log(LogLevel.Information, "Post Invoked", null);
                PersonDto person = new PersonDto() { Id = 4, Name = "Brett", Email = "stanselb@yahoo.com" };
                _personRepository.SavePerson(person);
            }
            catch (Exception ex)
            {
                _logger.Log(LogLevel.Error, ex.Message);
            }
        }

        // PUT: api/Person/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
