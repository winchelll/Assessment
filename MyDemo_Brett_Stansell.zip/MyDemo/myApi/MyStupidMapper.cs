﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using myData;

namespace myApi
{
    public class MyStupidPersonMapper
    {
        //I would use the enterprise's Object Mapper of choice here.


        public List<PersonModel> GetPersonList(List<PersonDto> personDtoList)
        {
            List<PersonModel> persons = new List<PersonModel>();

            foreach(PersonDto personDto in personDtoList)
            {
                persons.Add(new PersonModel() { Id = personDto.Id, Name = personDto.Name, Email = personDto.Email });
            }

            return (persons);
        }

        public PersonModel GetPerson(PersonDto personDto)
        {
            return (new PersonModel() { Id = personDto.Id, Name = personDto.Name, Email = personDto.Email });
        }
    }
}
