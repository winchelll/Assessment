﻿using System;
using System.Collections.Generic;
using System.Text;

namespace myData
{
    public class PersonRepository : IPersonRepostitory
    {
        List<PersonDto> _inMemoryList;

        private List<PersonDto> InMemoryList
        {
            get
            {
                if (_inMemoryList == null)
                {
                    _inMemoryList = new List<PersonDto>();
                    _inMemoryList.Add(new PersonDto { Id = 1, Name = "John Doe", Email = "doej@test.com" });
                    _inMemoryList.Add(new PersonDto { Id = 2, Name = "Jane Doe", Email = "doeja@test.com" });
                    _inMemoryList.Add(new PersonDto { Id = 3, Name = "Tom Smith", Email = "tom.smith@test.com" });
                }
                return (_inMemoryList);
            }
        }

        public PersonDto GetPerson(int id)
        {
            return (InMemoryList.Find(o => o.Id == id));
        }

        public List<PersonDto> GetPersons()
        {
            return (InMemoryList);
        }

        public void SavePerson(PersonDto personDto)
        {
            InMemoryList.Add(personDto);
        }
    }
}
