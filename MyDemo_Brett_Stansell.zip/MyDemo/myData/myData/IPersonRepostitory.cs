﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Linq.Expressions;

namespace myData
{
    public interface IPersonRepostitory
    {
        List<PersonDto> GetPersons();

        PersonDto GetPerson(int id);

        void SavePerson(PersonDto personDto);
    }
}
