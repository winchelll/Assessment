﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using myApi.Models;
using myData.ModelsDTO;
using myData.Repositories.Interfaces;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace myApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonController : ControllerBase
    {
        //repositories using denpendency injection
        private readonly IPersonRepository _personRepository;
        private readonly ILogger<PersonController> _logger;
        public PersonController(IPersonRepository personRepository, ILogger<PersonController> logger)
        {
            _personRepository = personRepository;
            _logger = logger;
        }

        


        // GET: api/<PersonController>
        [HttpGet]
        public IEnumerable<PersonModel> Get()
        {
            try
            {
                //calling repository from myData using DI
                var personsDTO = _personRepository.GetPersons();
                //map dto to model
                var persons = from p in personsDTO
                              select new PersonModel()
                              {
                                  Id = p.Id,
                                  Name = p.Name,
                                  Email = p.Email
                              };
                //log information
                _logger.LogInformation(1, "Get All Has been invoked", persons);
                return persons;
            }
            catch (Exception ex)
            {
                //log error
                _logger.LogError(2, "An exception has occured", ex.Message);
                throw ex;
            }
        }

        // GET api/<PersonController>/5
        [HttpGet("{id}")]
        public PersonModel Get(int id)
        {
            var personDto = _personRepository.GetPerson(id);
            PersonModel person = new PersonModel()
            { 
                Id = personDto.Id, 
                Name = personDto.Name, 
                Email = personDto.Email 
            };
            _logger.LogInformation(1, "Get person by Id Has been invoked", person);
            return person;
        }

        // POST api/<PersonController>
        [HttpPost]
        public void Post([FromBody] PersonModel person)
        {
            PersonDTO personDTO = new PersonDTO
            {
                Id = person.Id,
                Name = person.Name,
                Email = person.Email
            };
            _personRepository.SavePerson(personDTO);
            _logger.LogInformation(1, "Post person Has been invoked", person);
        }

        // PUT api/<PersonController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<PersonController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
