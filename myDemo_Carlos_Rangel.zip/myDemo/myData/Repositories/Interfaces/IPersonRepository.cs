﻿using myData.ModelsDTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace myData.Repositories.Interfaces
{
    public interface IPersonRepository
    {
        List<PersonDTO> GetPersons();
        PersonDTO GetPerson(int id);
        void SavePerson(PersonDTO Person);
    }
}
