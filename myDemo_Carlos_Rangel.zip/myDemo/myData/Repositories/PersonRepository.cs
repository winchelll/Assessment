﻿using myData.ModelsDTO;
using myData.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace myData.Repositories
{
    //Interface implementation
    public class PersonRepository : IPersonRepository
    {
        //In memory List
        private static List<PersonDTO> Persons = new List<PersonDTO>()
        {
                new PersonDTO()
        {
            Id = 1,
                    Name = "John Doe",
                    Email = "doej@test.com"
                },
                new PersonDTO()
        {
            Id = 2,
                    Name = "Jane Doe",
                    Email = "doeja@test.com"
                },
                new PersonDTO()
        {
            Id = 3,
                    Name = "Tom Smith",
                    Email = "tom.smith@test.com"
                },
            }; 

        public PersonDTO GetPerson(int id)
        {
            return Persons.Single(P => P.Id == id);
        }

        public List<PersonDTO> GetPersons()
        {
            return Persons;
        }

        public void SavePerson(PersonDTO Person)
        {
            Persons.Add(Person);
        }
    }
}
