﻿using MyData.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyData.Repositories
{
    public class PersonRepository : IPersonRepository
    {
        private static List<PersonDTO> personsData = new List<PersonDTO> {
            new PersonDTO { Id = 1, Name = "John Doe", Email = "doej@test.com" },
            new PersonDTO { Id = 2, Name = "Jane Doe", Email = "doeja@test.com" },
            new PersonDTO { Id = 3, Name = "Tom Smith", Email = "tom.smith@test.com" }
        };

        public PersonDTO GetPerson(int id)
        {
            return personsData.FirstOrDefault(x => x.Id == id);
        }

        public List<PersonDTO> GetPersons()
        {
            return personsData;
        }

        public void SavePerson(PersonDTO person)
        {
            personsData.Add(person);
        }
    }
}
