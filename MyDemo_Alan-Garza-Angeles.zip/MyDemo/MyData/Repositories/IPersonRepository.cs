﻿using MyData.DTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace MyData.Repositories
{
    public interface IPersonRepository
    {
        public List<PersonDTO> GetPersons();
        public PersonDTO GetPerson(int id);
        public void SavePerson(PersonDTO person);
    }
}
