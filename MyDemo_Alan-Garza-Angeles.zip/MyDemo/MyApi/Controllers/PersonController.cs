﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MyApi.Model;
using MyData.DTO;
using MyData.Repositories;

namespace MyApi.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class PersonController : ControllerBase
    {
        private readonly ILogger<PersonController> _logger;
        private readonly IMapper _mapper;
        private readonly IPersonRepository _personRepository;
        
        public PersonController(ILogger<PersonController> logger, IPersonRepository personRepository, IMapper mapper)
        {
            _logger = logger;
            _personRepository = personRepository;
            _mapper = mapper;
        }

        [HttpGet]
        public ActionResult<IList<PersonModel>> GetPersons()
        {
            try
            {
                _logger.LogInformation("Fetching persons");

                var persons = _personRepository.GetPersons();
                List<PersonModel> personsModel = _mapper.Map<List<PersonModel>>(persons);

                _logger.LogInformation("Persons fetched");

                return Ok(personsModel);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error ocurred: {ex.Message}", ex);
                throw ex;
            }
        }

        [HttpGet]
        [Route("{id}")]
        public ActionResult<PersonModel> GetPerson(int id)
        {
            try
            {
                _logger.LogInformation("Searching person");

                var persons = _personRepository.GetPerson(id);
                PersonModel personModel = _mapper.Map<PersonModel>(persons);

                if (personModel == null)
                    _logger.LogInformation("Person not found");
                else
                    _logger.LogInformation("Person found");

                return Ok(personModel);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error ocurred: {ex.Message}", ex);
                throw ex;
            }
        }

        [HttpPost]
        public void SavePerson(PersonModel person)
        {
            try
            {
                _logger.LogInformation("Saving person");

                var personDto = _mapper.Map<PersonDTO>(person);

                _personRepository.SavePerson(personDto);

                _logger.LogInformation("Person saved");
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error ocurred: {ex.Message}", ex);
                throw ex;
            }
        }
    }
}
